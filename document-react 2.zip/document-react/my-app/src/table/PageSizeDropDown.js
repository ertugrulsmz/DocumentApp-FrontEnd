import Dropdown from 'react-bootstrap/Dropdown';

function PageSizeDropDown(props) {

    const setPageSize = (number) => {
        props.setPageSize(number)
    }

    return (
        <Dropdown>
            <Dropdown.Toggle variant="success" id="dropdown-basic">
                Page Size
            </Dropdown.Toggle>

            <Dropdown.Menu>
                <Dropdown.Item onClick={() => setPageSize(5)}>5</Dropdown.Item>
                <Dropdown.Item onClick={() => setPageSize(10)}>10</Dropdown.Item>
                <Dropdown.Item onClick={() => setPageSize(20)}>20</Dropdown.Item>
                <Dropdown.Item onClick={() => setPageSize(50)}>50</Dropdown.Item>
                <Dropdown.Item onClick={() => setPageSize(100)}>100</Dropdown.Item>
            </Dropdown.Menu>
        </Dropdown>
    );
}

export default PageSizeDropDown;