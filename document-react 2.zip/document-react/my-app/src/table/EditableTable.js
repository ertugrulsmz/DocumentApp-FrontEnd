import {useEffect, useRef, useState} from 'react'
import './tablestyle.css'
import {Container} from "react-bootstrap";
import PaginationExampleShorthand from "./Pagination";
import PageSizeDropDown from "./PageSizeDropDown";
import ArrowUp from "../image/arrow-up.svg"
import ArrowDown from "../image/arrow-down.svg"
import SearchInput from "./SearchInput";
import filterTableDataBySearchFilter from "./TableUtil";
import {Button, ButtonGroup} from "@mui/material";
import UpDownButton from "./UpDownButton";
import InputComponent from "./InputComponent";

const EditableTable = (props) => {


    useEffect(() => {
        console.log("editable table render")
    }, [])

    const onChangeInput = (e, id, currentPosition) => {
        props.onInputChange(e, id);
        props.setPosition({
            documentId:id,
            field:e.target.name,
            position:currentPosition
        })
    }

    const onRowRemoved = (id)  => {
        props.onRowRemoved(id)
    }
    const onRowAdded = () => {
        props.onRowAdded()
    }

    const [filteredData, setFilteredData] = useState(props.employeeData)
    const [currentPage, setCurrentPage] = useState(0);

    console.log("filteredData", filteredData, props.employeeData)
    const pageCount = (Math.ceil(filteredData.length / props.pageSize));
    const startingIndex = currentPage * props.pageSize;
    const endingIndex = (currentPage + 1) * props.pageSize;
    console.log("starting - ending",startingIndex,endingIndex,pageCount)

    const [searchParam, setSearchParam] = useState({
         customerName:null,
        projectName:null,
        size:null,
        annualUnit:null,
        deadline:null,
        responsible:null,
        description:null
    })

    useEffect(() => {
        setFilteredData(prev => {
            const filtered = filterTableDataBySearchFilter(props.employeeData, searchParam)
            console.log("filtered", filtered)
            return filtered;
        })
    }, [searchParam, props.employeeData])

    function filter(e, field){
        const value = e.target.value;
        setSearchParam(prev => {
            const copy = {
                ...prev
            };
            copy[field] = value;
            return copy;
        })
    }

    const [sortedFilteredData, setSortedFilteredData] = useState(filteredData)
    const [sortData, setSortData] = useState({
        customerName:null,
        projectName:null,
        size:null,
        annualUnit:null,
        deadline:null,
        responsible:null,
        description:null
    })
    console.log("sortData", sortData)

    const onSortClicked = (name, direction) => {
        console.log("onSortClicked", name, direction);
        function setStateValue(prevState, fieldName, value) {
            if (fieldName === "customerName") {
                return {
                    ...prevState,
                    customerName: value
                }
            }
            if (fieldName === "projectName") {
                return {
                    ...prevState,
                    projectName: value
                }

            }
            if (fieldName === "size") {
                return {
                    ...prevState,
                    size: value
                }

            }
            if (fieldName === "annualUnit") {
                return {
                    ...prevState,
                    annualUnit: value
                }

            }
            if (fieldName === "deadline") {
                return {
                    ...prevState,
                    deadline: value
                }

            }
            if (fieldName === "responsible") {
                return {
                    ...prevState,
                    responsible: value
                }

            }
            if (fieldName === "description") {
                return {
                    ...prevState,
                    description: value
                }

            }
            throw Error("unknown field");
        }

        setSortData(prevState => {
            const currentDirection = sortData[name]
            if (currentDirection === direction) {
                   return setStateValue(prevState, name, null);
            }
            return setStateValue(prevState, name, direction);
        })



        }


    useEffect(() => {
        setSortedFilteredData(onSortClickedFunc(sortData, filteredData))
    }, [sortData, filteredData, setSortedFilteredData])

    function onSortClickedFunc(sortData1, data) {
        function stringSort(fa, fb, direction) {
            if (fa < fb) {
                return -1*direction;
            }
            if (fa > fb) {
                return 1*direction;
            }
            return 0;
        }

        const customerDirection = sortData1.customerName
        const projectNameDirection = sortData1.projectName
        const sizeDirection = sortData1.size
        const annualUnitDirection = sortData1.annualUnit
        const deadlineDirection = sortData1.deadline
        const responsibleDirection = sortData1.responsible
        const descriptionDirection = sortData1.description


        if (customerDirection == null && projectNameDirection == null && sizeDirection==null
        && annualUnitDirection == null && deadlineDirection == null && responsibleDirection == null
            && descriptionDirection == null
        ){
            return data;
        }

        return [...(data)].sort((a, b) => {
            console.log("a,b",a,b)
            let result;
            if (customerDirection != null) {
                const fa = a.customerName.toLowerCase();
                const fb = b.customerName.toLowerCase();
                result = stringSort(fa, fb, customerDirection);
                if (result !== 0){
                    console.log("result", result)
                    return result;
                }
            }
            if (projectNameDirection != null) {
                const fa = a.projectName.toLowerCase();
                const fb = b.projectName.toLowerCase();
                result = stringSort(fa, fb, projectNameDirection);
                if (result !== 0){
                    return result;
                }
            }
            if (sizeDirection != null) {
                const fa = a.size;
                const fb = b.size;
                result = stringSort(fa, fb, sizeDirection);
                if (result !== 0){
                    return result;
                }
            }
            if (annualUnitDirection != null) {
                const fa = a.annualUnit;
                const fb = b.annualUnit;
                result = stringSort(fa, fb, annualUnitDirection);
                if (result !== 0){
                    return result;
                }
            }
            if (deadlineDirection != null) {
                const fa = a.deadline;
                const fb = b.deadline;
                result = stringSort(fa, fb, deadlineDirection);
                if (result !== 0){
                    return result;
                }
            }
            if (responsibleDirection != null) {
                const fa = a.responsible.toLowerCase();
                const fb = b.responsible.toLowerCase();
                result = stringSort(fa, fb, responsibleDirection);
                if (result !== 0){
                    return result;
                }
            }
            if (descriptionDirection != null) {
                const fa = a.description.toLowerCase();
                const fb = b.description.toLowerCase();
                result = stringSort(fa, fb, descriptionDirection);
                if (result !== 0){
                    return result;
                }
            }

            return result;
        })
    }


    return (
        <div>
            <div className="container">
                <table>
                    <thead>
                    <tr>
                        <th>
                            Customer Name <br/>
                            <UpDownButton currentField="customerName" sortData={sortData}
                                          onDirectionChanged={onSortClicked}/>
                        </th>
                        <th>
                            Project Name <br/>
                            <UpDownButton currentField="projectName" sortData={sortData}
                                          onDirectionChanged={onSortClicked}/>
                        </th>
                        <th>
                            Size <br/>
                            <UpDownButton currentField="size" sortData={sortData}
                                          onDirectionChanged={onSortClicked}/>
                        </th>
                        <th>
                            AnnualUnit <br/>
                            <UpDownButton currentField="annualUnit" sortData={sortData}
                                          onDirectionChanged={onSortClicked}/>
                        </th>
                        <th>
                            Deadline <br/>
                            <UpDownButton currentField="deadline" sortData={sortData}
                                          onDirectionChanged={onSortClicked}/>
                        </th>
                        <th>
                            Responsible <br/>
                            <UpDownButton currentField="responsible" sortData={sortData}
                                          onDirectionChanged={onSortClicked}/>
                        </th>
                        <th>
                            Description <br/>
                            <UpDownButton currentField="description" sortData={sortData}
                                          onDirectionChanged={onSortClicked}/>
                        </th>
                        <th className="special-column"><button className="btn btn-outline-success" onClick={onRowAdded} >+</button></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><SearchInput onChange={(e) => filter(e, "customerName")} /></td>
                        <td><SearchInput onChange={(e) => filter(e, "projectName")}   /></td>
                        <td><SearchInput onChange={(e) => filter(e, "size")} /></td>
                        <td><SearchInput onChange={(e) => filter(e, "annualUnit")} /></td>
                        <td><SearchInput onChange={(e) => filter(e, "deadline")} /></td>
                        <td><SearchInput onChange={(e) => filter(e, "responsible")} /></td>
                        <td><SearchInput onChange={(e) => filter(e, "description")} /></td>

                    </tr>
                    {sortedFilteredData.slice(startingIndex, endingIndex).map(({ documentId, customerName, projectName, size, annualUnit,
                                                                                   deadline, responsible, description}) => (
                        <tr key={documentId}>
                            <td>
                                <input
                                    name="customerName"
                                    defaultValue={customerName}
                                    type="text"
                                    onChange={(e) => onChangeInput(e, documentId)}
                                    placeholder="Type Customer Name"
                                />
                            </td>
                            <td>
                                <input
                                    name="projectName"
                                    defaultValue={projectName}
                                    type="text"
                                    onChange={(e) => onChangeInput(e, documentId)}
                                    placeholder="Type Project Name"
                                />
                            </td>
                            <td>
                                <input
                                    name="size"
                                    type="number"
                                    defaultValue={size}
                                    onChange={(e) => onChangeInput(e, documentId)}
                                    placeholder="Type Size"
                                />
                            </td>
                            <td>
                                <input
                                    name="annualUnit"
                                    type="number"
                                    defaultValue={annualUnit}
                                    onChange={(e) => onChangeInput(e, documentId)}
                                    placeholder="Type Annual Unit"
                                />
                            </td>
                            <td>
                                <input
                                    name="deadline"
                                    type="text"
                                    defaultValue={deadline}
                                    onChange={(e) => onChangeInput(e, documentId)}
                                    placeholder="Type Deadline"
                                />
                            </td>
                            <td>
                                <input
                                    name="responsible"
                                    type="text"
                                    defaultValue={responsible}
                                    onChange={(e) => onChangeInput(e, documentId)}
                                    placeholder="Type Responsible"
                                />
                            </td>
                            <td>
                                <input
                                    name="description"
                                    type="text"
                                    defaultValue={description}
                                    onChange={(e) => onChangeInput(e, documentId)}
                                    placeholder="Type Description"
                                />
                            </td>
                            <td className="special-column">
                                <button className="btn btn-outline-danger" onClick={()=> onRowRemoved(documentId)}>x</button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
            <Container>
                <PaginationExampleShorthand current={currentPage} total={pageCount} setPageNumber={(num) => setCurrentPage(num-1) }/>
            </Container>
        </div>

    )
}

export default EditableTable