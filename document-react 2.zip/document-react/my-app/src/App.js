import './App.css';
import EditableTable from "./table/EditableTable";
import {useEffect, useRef, useState} from "react";
import 'bootstrap/dist/css/bootstrap.css';
import 'semantic-ui-css/semantic.min.css'
import getDocuments, {createDocument, deleteDocument, editDocument, getExcel} from "./api/ApiRequest";
import generateId from "./util/Functionality";
import {Button} from "@mui/material";
import Bar from "./page/Bar";
import {Container, Navbar} from "react-bootstrap";
import MainNavbar from "./page/MainNavbar";


const timeoutId = new Map();

function App() {
    const data = [
        {
            documentId: '01',
            customerName: 'John Doe',
            projectName: 'johndoe@email.com',
            size: 12,
            annualUnit: 1234,
            deadline: "2022-12-3",
            responsible: 'Jack',
            description: 'Frontend Developer',
        },
        {
            documentId: '02',
            customerName: 'Lal Doe',
            projectName: 'johndoe@email.com',
            size: 132,
            annualUnit: 11234,
            deadline: "2022-12-3",
            responsible: 'Eh',
            description: 'Frontend Developer',
        },
        {
            documentId: '03',
            customerName: 'AJohn Doe',
            projectName: 'johndoe@email.com',
            size: 812,
            annualUnit: 61234,
            deadline: "2022-11-3",
            responsible: 'Jack',
            description: 'Frontend Developer',
        },
        {
            documentId: '04',
            customerName: 'PJohn Doe',
            projectName: 'gjohndoe@email.com',
            size: 33312,
            annualUnit: 1234,
            deadline: "2022-12-3",
            responsible: 'HJack',
            description: 'Frontend Developer',
        },
        {
            documentId: '05',
            customerName: 'John Doe',
            projectName: 'johndoe@email.com',
            size: 12,
            annualUnit: 1234,
            deadline: "2022-12-3",
            responsible: 'Jack',
            description: 'Frontend Developer',
        },
        {
            documentId: '06',
            customerName: 'Xohn Doe',
            projectName: 'fjohndoe@email.com',
            size: 912,
            annualUnit: 41234,
            deadline: "2023-12-3",
            responsible: 'Tack',
            description: 'Frontend Developer',
        },
        {
            documentId: '07',
            customerName: 'Pohn Doe',
            projectName: 'Tohndoe@email.com',
            size: 2,
            annualUnit: 134,
            deadline: "2020-12-3",
            responsible: 'Jack',
            description: 'Frontend Developer',
        }

    ]

    useEffect(() => {
        getDocuments()
            .then((data) => {
                setDocumentData(data)
            })
    }, [])

    const [documentData, setDocumentData] = useState([])
    const documentRef = useRef(documentData)

    useEffect( () => console.log("mount"), [] );

    useEffect( () => () => {
        console.log("employeeData useEffect : ", documentData)
        timeoutId.clear()
        console.log("unmount")
    }, [] );

    const [position, setCurrentPosition] = useState({
         documentId:null,
        field:null,
        position:null
    })

    const [pageSize, setPageSize] = useState(5);


    function onInputChange(e, documentId) {
        const {name, value} = e.target
        console.log("onInput Change", name, value)

        setDocumentData(prevState => {
            const values = prevState.map((item) =>
                item.documentId === documentId && name ? {...item, [name]: value} : item
            );
            documentRef.current = values;
            return values
        })

        const timeOutIdForSingleItem = timeoutId.get(documentId);
        if (timeOutIdForSingleItem) {
            clearTimeout(timeOutIdForSingleItem);
        }

        const newTimeOutItem = setTimeout(() => {
            const documentToEdit = documentRef.current.filter(d => d.documentId === documentId)
            console.log("documents", documentData)
            console.log("document to edit", documentToEdit)
            editDocument(documentToEdit.at(0)).catch(e => console.log("Error occurred while sending request", e))
        }, 1500);
        timeoutId.set(documentId, newTimeOutItem)
    }


    function onRowAdded() {
        let newDocument = {
            documentId: generateId(35),
            customerName: '',
            projectName: '',
            size: '',
            annualUnit: '',
            deadline: '',
            responsible: '',
            description: '',
        };

        setDocumentData(prev => {
            return [newDocument, ...prev];
        })

        createDocument(newDocument)
            .catch(e => console.log("document is not added", e));

    }

    function onRowRemoved(documentId) {
        setDocumentData(prev => {
            return prev.filter(item => item.documentId !== documentId);
        })

        deleteDocument(documentId).catch(e => console.log("Error while deleting", e))
    }

    function onExcelDownloand() {
        getExcel();
    }

    return (
    <div className="App">
      <Container>
          <Bar setPageSize={setPageSize} />
        <EditableTable pageSize={pageSize} employeeData={documentData} onInputChange={onInputChange}
        onRowAdded={onRowAdded} onRowRemoved={onRowRemoved} position={position}
                   setPosition={setCurrentPosition}
        />
      </Container>
    </div>
  );
}

export default App;
