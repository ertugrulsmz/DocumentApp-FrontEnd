import {getExcel} from "../api/ApiRequest";
import PageSizeDropDown from "../table/PageSizeDropDown";
import 'bootstrap/dist/css/bootstrap.css';
import excel from "../image/excel.png"
import FileUpload from "./fileUpload";

const Bar = (props) => {
    return (
      <div>
          <ul className="nav nav-tabs">
              <li className="nav-item withPadding">
                  <FileUpload/>
              </li>
              <li className="nav-item withPadding">
                  <img className={"excelImage"} onClick={() => getExcel()} src={excel} width={30} height={30}/>
              </li>
              <li className="nav-item withPadding">
                  <PageSizeDropDown setPageSize={props.setPageSize} />
              </li>
          </ul>
      </div>

    )
}
export default Bar;