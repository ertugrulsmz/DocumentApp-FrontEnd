import axios from "axios";
import React from "react";
import download from 'js-file-download';


const baseURL = "http://localhost:8084/v1/document";

const getDocuments = () => {
    return axios.get(baseURL)
        .then(response => {
            return response.data.map(data => {
                return {
                    documentId:data.publicId,
                    customerName:data.customerName,
                    projectName:data.projectName,
                    size:data.size,
                    annualUnit:data.annualUnit,
                    deadline:data.deadline,
                    responsible:data.responsible,
                    description:data.description,
                }
            })

        }).catch((e) => {
            console.log("error occurred while getting", e)
    })
}

export const createDocument = (data) => {
    return axios.post(baseURL, {
        publicId: data.documentId,
        customerName:data.customerName,
        projectName:data.projectName,
        size:data.size,
        annualUnit:data.annualUnit,
        deadline:data.deadline,
        responsible:data.responsible,
        description:data.description,
    })
}

export const editDocument = (data) => {
    console.log("documentId to patch",data)
    console.log("documentId", data.documentId)
    return axios.patch(baseURL + "/" + data.documentId, {
        customerName:data.customerName,
        projectName:data.projectName,
        size:data.size,
        annualUnit:data.annualUnit,
        deadline:data.deadline,
        responsible:data.responsible,
        description:data.description,
    })
}

export const getExcel = () => {

    axios({
        method: 'get',
        url: baseURL + "/download-excel",
        responseType: 'blob', // important
    }).then(response => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'document.xlsx');
        document.body.appendChild(link);
        link.click();
    });
}

export async function uploadFile(formData) {
    try {
        const response = axios.post(baseURL + "/upload-excel", formData, {
            headers: { "Content-Type": "multipart/form-data" },
        })

        response.then(r => console.log(""))
    } catch (error) {
        console.error(error);
    }
}


export const deleteDocument = (documentId) => {
    return axios.delete(baseURL + "/" + documentId);
}

export default getDocuments;
