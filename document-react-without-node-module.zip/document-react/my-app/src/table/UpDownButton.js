import {Button, ButtonGroup} from "@mui/material";

const UpDownButton = (props) => {

    const directionOfState = props.sortData[props.currentField];

    let upButton;
    let downButton;

    function onDirectionChanged(currentField, number) {
        console.log("on Direction Changed")
        props.onDirectionChanged(currentField, number)
    }

    if (directionOfState === 1 ){
        upButton = <Button  variant="contained" onClick={() => onDirectionChanged(props.currentField, 1)}>Down</Button>
        downButton = <Button onClick={() => onDirectionChanged(props.currentField, -1)}>Up</Button>
    }
    else if (directionOfState === -1){
        upButton = <Button onClick={() => onDirectionChanged(props.currentField, 1)}>Down</Button>
        downButton = <Button variant="contained" onClick={() => onDirectionChanged(props.currentField, -1)}>Up</Button>
    }
    else if(directionOfState == null ){
        upButton = <Button onClick={() => onDirectionChanged(props.currentField, 1)}>Down</Button>
        downButton = <Button onClick={() => onDirectionChanged(props.currentField, -1)}>Up</Button>
    }

    return (
        <ButtonGroup className="sortButtonGroup" size="small" aria-label="small button group">
            {upButton}
            {downButton}
        </ButtonGroup>
    )
}

export default UpDownButton;