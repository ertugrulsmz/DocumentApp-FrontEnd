const filterTableDataBySearchFilter = (data, searchFilter) => {

    function isMatch(field, searchParam) {
        if (searchParam === null){
            return true;
        }

        const searchParamProcessed = searchParam.toLowerCase().trim();
        if(searchParamProcessed === ""){
           return true;
        }

        console.log("field", field, searchParam)
        return field.toString().toLowerCase().startsWith(searchParamProcessed);
    }

    function isEmpty(d) {
        if (d.customerName != null && d.customerName.toString().trim() !== ""){
            return false;
        }
        if (d.projectName != null && d.projectName.toString().trim() !== ""){
            return false;
        }

        if (d.size != null && d.size.toString().trim() !== ""){
            return false;
        }

        if (d.annualUnit != null && d.annualUnit.toString().trim() !== ""){
            return false;
        }

        if (d.deadline != null && d.deadline.toString().trim() !== ""){
            return false;
        }

        if (d.responsible != null && d.responsible.toString().trim() !== ""){
            return false;
        }

        if (d.description != null && d.description.toString().trim() !== ""){
            return false;
        }

        return true;
    }

    return data.filter(d => {
        const match1 = isMatch(d.customerName, searchFilter.customerName)
        const match2 = isMatch(d.projectName, searchFilter.projectName)
        const match3 = isMatch(d.size, searchFilter.size)
        const match4 = isMatch(d.annualUnit, searchFilter.annualUnit)
        const match5 = isMatch(d.deadline, searchFilter.deadline)
        const match6 = isMatch(d.responsible, searchFilter.responsible)
        const match7 = isMatch(d.description, searchFilter.description)
        return match1 && match2 && match3 && match4 && match5 && match6 && match7;
    })
}

export default filterTableDataBySearchFilter;