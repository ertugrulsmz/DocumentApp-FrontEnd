const SearchInput = (props) => {
    return (
        <input onChange={props.onChange}
            type="text" className="form-control" placeholder="Search..." />
    )
}

export default SearchInput