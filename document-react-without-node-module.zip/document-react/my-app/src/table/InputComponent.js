import React, {useEffect, useLayoutEffect, useRef} from "react";

const InputComponent = ({onChange, name, type, placeHolder, value, position, documentId}) => {

    const inputRef = useRef(null);
    console.log("position in ",name,position, documentId)
    let matched;

    let inputPosition = null;
    if (documentId === position.documentId && name === position.field){
        console.log("position match here continue")
        inputPosition = parseInt(position.position);
        matched = true
    }
    else {
        inputPosition = value.length;
        matched = false
    }

    useEffect(() => {
        console.log("USEEEEEEEEEEEEALEFHAEUWOFHAOEIUFHOIEAH")
        inputRef.current.setSelectionRange(inputPosition, inputPosition);
        if (matched){
        console.log("matchedd", inputPosition, inputRef.current, inputRef.current.position)
        //inputRef.current.focus();
        }
    }, [position]);



    console.log("inputPosition", inputPosition)

    return (
        <input
            ref={inputRef}
            name={name}
            onChange={(e) => onChange(e, documentId, inputRef.current.selectionStart)}
            defaultValue={value}
            type={type}
            placeholder={placeHolder}
        />
    );
};

export default InputComponent;