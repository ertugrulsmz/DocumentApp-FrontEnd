import React, {useRef, useState} from 'react';
import {uploadFile} from "../api/ApiRequest";
import {Button} from "@mui/material";

const FileUpload = () => {
  const [file, setFile] = useState(null);
  const [random, setRandom] = useState(0)

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };


  const handleUpload = async () => {
    const formData = new FormData();
    formData.append('file', file);
    await uploadFile(formData);
    setFile(null);
    setRandom(Math.random())
  };

  return (
      <div>
          <input type="file" onChange={handleFileChange} key={random}  />
          <br/>
          {file && <Button onClick={handleUpload}>Upload</Button>}
      </div>
  );
};

export default FileUpload;